#ifndef FEEDBACK_H
#define FEEDBACK_H

#define LED_PIN 13
#define BUZZER_PIN 7

void setupHardware();
void TaskFeedbackAndLog(void *pvParameters);
const char* getStateText(int state);

#endif
