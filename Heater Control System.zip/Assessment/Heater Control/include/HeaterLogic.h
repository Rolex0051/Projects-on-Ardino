#ifndef HEATER_LOGIC_H
#define HEATER_LOGIC_H

#define HEATER_PIN 8

#define TEMP_THRESHOLD_ON     25.0
#define TEMP_THRESHOLD_OFF    30.0
#define TEMP_OVERHEAT         40.0
#define TEMP_STABILIZING_LOW  28.0
#define TEMP_TARGET           29.0

enum HeaterState {
  IDLE,
  HEATING,
  STABILIZING,
  TARGET_REACHED,
  OVERHEAT
};

extern volatile HeaterState currentState;
extern volatile bool heater_on;
extern volatile float currentTemperature;

void TaskHeaterControl(void *pvParameters);

const char* stateToString(HeaterState state);  // Declaration only

#endif
