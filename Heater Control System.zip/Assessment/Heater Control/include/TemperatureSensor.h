#ifndef TEMPERATURE_SENSOR_H
#define TEMPERATURE_SENSOR_H

#define TEMP_SENSOR_PIN A0

extern volatile float currentTemperature;

void TaskTemperatureRead(void *pvParameters);

#endif
