Example 2
=========

Same as the first example, but now using Unity's test fixture to group tests
together. Using the test fixture also makes writing test runners much easier.