#include <Arduino.h>
#include <Arduino_FreeRTOS.h>
#include "FreeRTOSConfig.h"
#include "task.h"
#include "TemperatureSensor.h"

// Define the analog pin for the temperature sensor if not already defined
#ifndef TEMP_SENSOR_PIN
#define TEMP_SENSOR_PIN A0
#endif

volatile float currentTemperature = 0.0;

void TaskTemperatureRead(void *pvParameters) {
  (void) pvParameters;
  for (;;) {
    int adc = analogRead(TEMP_SENSOR_PIN);
    float voltage = adc * (5.0 / 1023.0);
    currentTemperature = voltage * 100.0;
    vTaskDelay(pdMS_TO_TICKS(500));
  }
}
