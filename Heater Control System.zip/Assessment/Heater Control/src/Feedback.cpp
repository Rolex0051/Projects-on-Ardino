#include <Arduino.h>
#define ARDUINO_H
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <Arduino_FreeRTOS.h>
#include "FreeRTOSConfig.h"
#include "task.h"
#include "HeaterLogic.h"
#include "Feedback.h"
#include "TemperatureSensor.h"

volatile HeaterState currentState = IDLE;
volatile bool heater_on = false;
void setupHardware() {
  pinMode(HEATER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  Serial.begin(9600);
}

void TaskFeedbackAndLog(void *pvParameters) {
  (void) pvParameters;
  for (;;) {
    if (currentState == HEATING || currentState == OVERHEAT) {
      digitalWrite(LED_PIN, HIGH);
    } else {
      digitalWrite(LED_PIN, LOW);
    }

    if (currentState == OVERHEAT) {
      digitalWrite(BUZZER_PIN, HIGH);
    } else {
      digitalWrite(BUZZER_PIN, LOW);
    }

    Serial.print("Temperature: ");
    Serial.print(currentTemperature);
    Serial.print(" °C | State: ");
    Serial.print(getStateText(currentState));
    Serial.print(" | Heater: ");
    Serial.println(heater_on ? "ON" : "OFF");

    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

const char* getStateText(int state) {
  switch (state) {
    case IDLE: return "Idle";
    case HEATING: return "Heating";
    case STABILIZING: return "Stabilizing";
    case TARGET_REACHED: return "Target Reached";
    case OVERHEAT: return "Overheat";
    default: return "Unknown";
  }
}
