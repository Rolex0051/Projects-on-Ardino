#include <Arduino.h>
#include <Arduino_FreeRTOS.h>
#include "task.h"

#include "HeaterLogic.h"
#include "TemperatureSensor.h"

// FreeRTOS Task Declaration
void TaskHeaterControl(void *pvParameters);

// Setup function to initialize system
void setup() {
  Serial.begin(9600);
  pinMode(HEATER_PIN, OUTPUT);
  digitalWrite(HEATER_PIN, LOW);

  // Start temperature reading and heater control as tasks
  xTaskCreate(TaskHeaterControl, "HeaterControl", 128, NULL, 1, NULL);
  xTaskCreate(TaskTemperatureRead, "TempSensor", 128, NULL, 1, NULL);
}

// Loop is unused in FreeRTOS
void loop() {
  // Empty – FreeRTOS takes control
}

// Heater Control Logic
void TaskHeaterControl(void *pvParameters) {
  (void) pvParameters;
  for (;;) {
    float temp = currentTemperature;

    if (temp > TEMP_OVERHEAT) {
      currentState = OVERHEAT;
    } else if (temp >= TEMP_TARGET) {
      currentState = TARGET_REACHED;
    } else if (temp >= TEMP_STABILIZING_LOW) {
      currentState = STABILIZING;
    } else if (heater_on) {
      currentState = HEATING;
    } else {
      currentState = IDLE;
    }

    // Heater Control
    if (currentState == OVERHEAT || temp > TEMP_THRESHOLD_OFF) {
      digitalWrite(HEATER_PIN, LOW);
      heater_on = false;
    } else if (temp < TEMP_THRESHOLD_ON) {
      digitalWrite(HEATER_PIN, HIGH);
      heater_on = true;
    }

    // Debug Info
    Serial.print("Temp: ");
    Serial.print(temp);
    Serial.print(" °C, State: ");
    Serial.println(stateToString(currentState));

    vTaskDelay(pdMS_TO_TICKS(200));
  }
}
const char* stateToString(HeaterState state) {
  switch (state) {
    case IDLE: return "Idle";
    case HEATING: return "Heating";
    case STABILIZING: return "Stabilizing";
    case TARGET_REACHED: return "Target Reached";
    case OVERHEAT: return "Overheat";
    default: return "Unknown";
  }
}