Import("env")
import os
import shutil

build_dir = env.subst("$BUILD_DIR")
project_dir = env.subst("$PROJECT_DIR")

hex_file = os.path.join(build_dir, "firmware.hex")
bin_file = os.path.join(build_dir, "firmware.bin")
output_dir = os.path.join(project_dir, "build_output")
output_bin_file = os.path.join(output_dir, "uno_firmware.bin")

os.makedirs(output_dir, exist_ok=True)

objcopy = env.get("OBJCOPY")

# Convert .hex to .bin
if os.path.exists(hex_file):
    print(f"🔧 Converting HEX → BIN: {hex_file} → {bin_file}")
    env.Execute(f'"{objcopy}" -I ihex -O binary "{hex_file}" "{bin_file}"')

    if os.path.exists(bin_file):
        shutil.copy(bin_file, output_bin_file)
        print(f"✅ Copied to {output_bin_file}")
    else:
        print("❌ BIN not created.")
else:
    print("❌ HEX file not found. Build might have failed.")
